﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CandleActions : MonoBehaviour {

    private Vector3 startingPosition;
    private Renderer renderer;

    // The one that will zoom
    public GameObject Player;
    // The target of the zoom
    public GameObject Target;
    // Where to zoom (coordinates)
    public Vector3 positionToZoom;
    // Coordinates to return to after zoom
    public Vector3 positionToReturn;
    // Boolean to know status of zoom
    private bool zoomStatus;

    public Material inactiveMaterial;
    public Material gazedAtMaterial;

    void Start()
    {
        startingPosition = transform.localPosition;
        renderer = GetComponent<Renderer>();
        SetGazedAt(false);
        zoomStatus = false;
    }

    public void SetGazedAt(bool gazedAt)
    {
        if (inactiveMaterial != null && gazedAtMaterial != null)
        {
            renderer.material = gazedAt ? gazedAtMaterial : inactiveMaterial;
            return;
        }
    }

    public void ZoomIn()
    {
        // Store original character coordinates
        positionToReturn = Player.transform.position;
        // Get coordinates of target
        positionToZoom = Target.transform.position;
        Debug.Log("Zoom Coordinates: " + positionToZoom);

        // Move Player to that position
        Player.transform.position = new Vector3(positionToZoom.x, positionToZoom.y, positionToZoom.z);

        // Function needs to be adjusted for the size of map... this thing is horrible sized
        // Reticle acts until very close to object

        // Activate Candle sound
        CandleFireSound();
        CandleLightning();

        zoomStatus = true;
    }

    public void ZoomOut()
    {
        // Needs original coordinates of character to return
        Debug.Log("Return Coordinates: " + positionToReturn);
        // Send Player to those coordinates
        Player.transform.position = new Vector3(positionToReturn.x, positionToReturn.y, positionToReturn.z);

        CandleLightning();

        zoomStatus = false;
    }

    public void ZoomHandler()
    {
        if (zoomStatus == false)
        {
            ZoomIn();
        } else if (zoomStatus == true)
        {
            ZoomOut();
        } else
        {
            Debug.Log("You somehow fckd up????");
        }
    }

    public void CandleFireSound()
    {
        Debug.Log("Burn fckn mortal !!!!!!!!!!!!!");
    }

    public void CandleLightning()
    {
        Debug.Log("Who turned of the lights?");
        Debug.Log("My eyes!!!! It burns");
    }

    public void Recenter()
    {
#if !UNITY_EDITOR
      GvrCardboardHelpers.Recenter();
#else
        if (GvrEditorEmulator.Instance != null)
        {
            GvrEditorEmulator.Instance.Recenter();
        }
#endif  // !UNITY_EDITOR
    }
}
